from data_ingestion import create_db_engine, query_data, read_from_web_CSV


def create_db_engine(db_path):
    """
    make sure create_db_engine works perfectly
    """

def query_data(engine, sql_query):
    """
    make sure query_data works
    """

def read_from_web_CSV(URL):
   """
   make sure read_from_web_CSV works
   """